import "./styles.css";
import Client from "./components/Client";
import axios from "axios";

export default function App() {
  return (
    <div className="App">
      hola
      <Client />
    </div>
  );
}
